
  <div class="content">
        <h2 class="text-primary">Dashboard <small>Statistic Overview</small></h2>
        <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
        <div class="row mb-5">
          <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <img class="" src="..." alt="">
        <div class="card-body">
          <h5 class="card-title "><i class="fa fa-users"></i> All Students 10</h5>
          
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <img class="" src="..." alt="">
        <div class="card-body">
          <h5 class="card-title "><i class="fa fa-users"></i> All Students 10</h5>
          
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <img class="" src="..." alt="">
        <div class="card-body">
          <h5 class="card-title "><i class="fa fa-users"></i> All Students 10</h5>
          
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
        </div>
        </div>

        
          </div>
           <hr>
           <h3>New Student</h3>
           <div class="responsive">
            
            <table id="example" class="table table-hover table-bordered" style="width:100%">
             <thead>
               <tr>
                 <th>ID</th>
                 <th>Name</th>
                 <th>Roll</th>
                 <th>City</th>
                 <th>Contact</th>
                  <th>Photo</th>
               </tr>
             </thead>
             <tbody>
               <tr>
                 <td>1</td>
                 <td>Kazi Aftabur Rahman</td>
                 <td>101</td>
                 <td>Dhaka</td>
                 <td>01711241129</td>
                 <td><img style="width:100px" src="images/1111.jpg"></td>
                 </tr>
                 <tr>
                 <td>1</td>
                 <td>Kazi Aftabur Rahman</td>
                 <td>102</td>
                 <td>Dhaka</td>
                 <td>01711241129</td>
                 <td><img style="width:100px" src="images/125.jpg"></td>
                 </tr>
                 <tr>
                 <td>1</td>
                 <td>Kazi Aftabur Rahman</td>
                 <td>103</td>
                 <td>Dhaka</td>
                 <td>01711241129</td>
                 <td><img style="width:100px" src="images/download (2).jpg"></td>
                 </tr>
             </tbody>
           </table> -->
           </div>
          </nav>
      </div>
